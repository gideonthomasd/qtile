# dwm
Install arcolinux - no window managers

Get tar file.  For dwm get dwmzip.tar.gz  

Do tar -xzvf dwmzip.tar.gz to unrar
